import{l as o,a as r}from"../chunks/C2joTuqi.js";export{o as load_css,r as start};
