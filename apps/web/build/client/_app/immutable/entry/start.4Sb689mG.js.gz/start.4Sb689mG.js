import{l as o,a as r}from"../chunks/Ci3tcnWT.js";export{o as load_css,r as start};
