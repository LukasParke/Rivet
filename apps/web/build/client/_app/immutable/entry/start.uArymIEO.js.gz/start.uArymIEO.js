import{l as o,a as r}from"../chunks/BkIcy94D.js";export{o as load_css,r as start};
