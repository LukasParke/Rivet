import{D as a}from"./Dc2GWTX7.js";a();
