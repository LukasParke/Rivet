import{B as a}from"./CMLA4Spu.js";a();
